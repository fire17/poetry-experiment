def main():
    print("Hello, world! PUBLISHED with POETRY!")

if __name__ == "__main__":
	print("RUNNING PROGRAM")
	main()
