# This files is used to run program as a module: python3.11 -m poetry_experiment
from .program import main

if __name__ == "__main__":
	main()
